#!/bin/bash

paste -d "\t" Paml_alt_out Paml_null_out | awk '{print$1"\t"$5"\t"$6"\t"$12"\t"$13}' | awk '{print$1"\t"$3"\t"$5}' > paml_lnL.txt

Rscript lrt_calculation.R

awk '{print$NF}' 1_LTR | sed -s '1d' > list_pval

cat list_pval | while read pval ; do

	chi2 1 $pval | sed -e "s/df/$pval\tdf/g" >> result_pval.txt

done

awk '{print$NF"\t"$2}' 1_LTR | sed '1d' | sed 's/"//g' > list_name

awk 'NR == FNR{a[$1] = $0;next}; {print $1, $1 in a?a[$1]: "NA"}'  result_pval.txt list_pval | grep -v "NA" | grep -v "prob = 1.000000000" | grep -v "invalid" |  awk '{$1=""}1' | sed 's/^.//g' > pval_paml.txt

awk 'NR == FNR{a[$1] = $0;next}; {print $1, $1 in a?a[$1]: "NA"}' list_name pval_paml.txt | awk '{print$NF}' > list_seq

paste -d "\t" list_seq pval_paml.txt | sed 's/df/\tdf/g' | sed 's/1 prob/\t1 prob/g' > 2_codeml_pval.txt

rm list_name list_pval list_seq

rm pval_paml.txt result_pval.txt paml_lnL.txt

cat *_codeml_pval.txt | awk '{if ($8<=0.05) print$0}' > seq_pval.txt
