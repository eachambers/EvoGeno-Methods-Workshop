#!/bin/bash

mkdir Codeml 

cat list_scg.txt | while read seq
do

  mafft --anysymbol --parttree --retree 1 --thread 4 ${seq}_scg.faa > align_${seq}.faa
  backtranseq -sequence ${seq}_scg.faa -outfile ${seq}_nuc.fasta
  perl pal2nal.pl align_${seq}.faa ${seq}_nuc.fasta -output paml -nogap -codontable 1 > paml_${seq}.fasta
  raxmlHPC-PTHREADS -s align_${seq}.faa -n ${seq}.tree -m PROTCATJTT -p 12345 -T 4
  mv RAxML_bestTree.${seq}.tree ${seq}.tree 
  mv ${seq}.tree Codeml/
  mv paml_${seq}.fasta Codeml/
  rm align_${seq}.fa* ${seq}_nuc.fasta RAxML_*
  
done
