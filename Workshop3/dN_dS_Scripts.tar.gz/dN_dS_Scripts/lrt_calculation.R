#!/usr/bin/env Rscript

#setwd("/Documents/GenFamily_Phyllostomids/16_PAML/Codeml_Ortho/lyerbabuenae/")
lnl <- read.table(file = "paml_lnL.txt", header = FALSE)
lnl$Ln <- lnl$V2-lnl$V3
lnl$LRT <- lnl$Ln*2
write.table(lnl, file="1_LTR", quote=FALSE)
