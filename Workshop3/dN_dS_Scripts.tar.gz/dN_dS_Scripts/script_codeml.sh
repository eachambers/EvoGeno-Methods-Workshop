#!/bin/bash

mkdir Paml_null

cat list_scg.txt | while read paml 
do
## Null

	sed -i -r "s/paml_[0-9]+.fasta/paml_${paml}.fasta/g" codeml.ctl 
	sed -i -r "s/[0-9]+.tree/${paml}.tree/g" codeml.ctl
	sed -i -r "s/[0-9]+.mcl/${paml}.mcl/g" codeml.ctl

	codeml codeml.ctl

	grep "lnL(ntime:" ${paml}.mcl | sed "s/lnL/${paml}\tlnL/g" >> Paml_null_out

	mv ${paml}.mcl Paml_null/
  
	rm rub 2NG* 4fold.nuc rs*  lnf 
done
