#!/bin/bash

mkdir Paml_alt
#mkdir Paml_null

cat list_scg.txt | while read paml
do

## Alternative
	sed -i -r "s/paml_[0-9]+.fasta/paml_${paml}.fasta/g" codeml_alt.ctl 
	sed -i -r "s/[0-9]+.tree/${paml}.tree/g" codeml_alt.ctl
	sed -i -r "s/[0-9]+_alt.mcl/${paml}_alt.mcl/g" codeml_alt.ctl
	codeml codeml_alt.ctl
	grep "lnL(ntime:" ${paml}_alt.mcl | sed "s/lnL/${paml}\tlnL/g" >> Paml_alt_out
	mv ${paml}_alt.mcl Paml_alt/
	rm rub 2NG* 4fold.nuc rs*  lnf
done	
